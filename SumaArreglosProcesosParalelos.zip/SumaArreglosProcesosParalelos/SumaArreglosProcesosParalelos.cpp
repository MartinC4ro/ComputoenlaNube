// SumaArreglosProcesosParalelos.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <omp.h>


int A[1000], B[1000], C[1000];

using namespace std;
#define NUM_THREADS 2

int main() {


    int logiarray, nthreads;
    omp_set_num_threads(NUM_THREADS);

    //Se define la longitud de los arreglos

    cout << "Favor de indicar cual es la longitud de los arreglos :";
    cin >> logiarray;

    //Seccion donde se llena en automatico la informacion de cada arreglo A y B

    srand(time(0));

    for (int i = 0; i < logiarray; i++) {
        A[i] = 1 + rand() % 50;
        B[i] = 60 + rand() % 90;
    }

    cout << "\n Descripcion por Thread en cada operacion: \n" << endl;

    //Seccion para sumar los arreglos

    int totalthrds1 = 0; int totalthrds0 = 0;

#pragma omp parallel
    {
        int i, id, nthrds;
        id = omp_get_thread_num();
        nthrds = omp_get_num_threads();
        if (id == 0) nthreads = nthrds;
        for (i = id, C[i] = 0.0; i < logiarray; i = i + nthrds)
        {
            C[i] = A[i] + B[i];

            if (id == 0)
            {
                totalthrds0 = totalthrds0 + 1;
            }
            else
            {
                totalthrds1 = totalthrds1 + 1;
            }


            cout << " El Thread [" << id << "] proceso A [" << i << "] -> " << A[i] << " + B [" << i << "] -> " << B[i] << " y el resultado de la suma es : C[" << i << "] -> " << C[i] << "\n" << endl;
        }


    }


    // Secci�n para mostrar la informacion

    cout << " El total de procesos ejecutados por Thread [0] fue de : " << totalthrds0 << " \n" << endl;

    cout << " El total de procesos ejecutados por Thread [1] fue de : " << totalthrds1 << " \n" << endl;



    cout << "A continuacion se despliega el contenido de cada arreglo \n" << endl;

    cout << "Contenido del arreglo A \n" << endl;

    int i = 0;
    for (i = 0; i < logiarray; i++) {
        cout << " A [" << i << "] -> " << A[i] << endl;
    }
    cout << endl;

    cout << "Contenido del arreglo B \n" << endl;

    for (i = 0; i < logiarray; i++) {
        cout << " B [" << i << "] -> " << B[i] << endl;
    }
    cout << endl;

    cout << "Contenido del arreglo C \n" << endl;

    for (i = 0; i < logiarray; i++) {
        cout << " C [" << i << "] -> " << C[i] << endl;
    }
    cout << endl;

}


// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
